Помощник @helper270926bot

На Railway в Variables:
TELEGRAM_BOT_TOKEN = токен от BotFather
XAI_API_KEY = ключ с console.x.ai
XAI_MODEL = grok-4-fast

Start command: python bot.py
